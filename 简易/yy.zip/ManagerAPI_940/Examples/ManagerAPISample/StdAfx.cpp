//+------------------------------------------------------------------+
//|                                                       MetaTrader |
//|                   Copyright 2001-2014, MetaQuotes Software Corp. |
//|                                        http://www.metaquotes.net |
//+------------------------------------------------------------------+
// stdafx.cpp : source file that includes just the standard includes
//   ManagerAPISample.pch will be the pre-compiled header
//   stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"
//+------------------------------------------------------------------+

//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by BalanceManager.rc
//
#define IDD_BALANCEMANAGER_DIALOG       102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define IDD_SETTINGS                    130
#define IDC_CLIENT                      1006
#define IDC_REQUEST                     1007
#define IDC_NAME                        1008
#define IDC_COUNTRY                     1009
#define IDC_CITY                        1010
#define IDC_DEPOSIT                     1011
#define IDC_WITHDRAWAL                  1012
#define IDC_BALANCE                     1013
#define IDC_AMOUNT                      1014
#define IDC_COMMENT                     1015
#define IDC_LOG                         1016
#define IDC_EXIT                        1017
#define IDC_SETTINGS                    1018
#define IDC_SERVER                      1018
#define IDC_LOGIN                       1019
#define IDC_PASSWORD                    1020

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1024
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
